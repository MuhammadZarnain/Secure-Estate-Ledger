export const SEL=[
    {name:'Introduction',link:'#'},
    {name:'Board Members',link:'#'},
    {name:'Core Team',link:'#'},
    {name:'Reviews',link:'#'},
    {name:'Careers',link:'#'},
];

export const Company=[
    {name:'Home',link:'#'},
    {name:'Contact Us',link:'#'},
    {name:'About Us',link:'#'},
    {name:'Services',link:'#'},
    {name:'Login',link:'#'},
];

export const Follow=[
    {name:'Facebook',link:'#'},
    {name:'X',link:'#'},
    {name:'LinkedIn',link:'#'},
    {name:'Instagram',link:'#'},
    {name:'YouTube',link:'#'},
];
export const Icons=[
    {name:'facebook',link:'#'},
    {name:'x',link:'#'},
    {name:'linkedin',link:'#'},
    {name:'instagram',link:'#'},
    {name:'youtube',link:'#'},
];