import React from 'react'

const pendingRequest = () => {
  return (
    <h1>Hello World</h1>
  )
}

export default pendingRequest