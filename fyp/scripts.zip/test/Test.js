const { expect } = require("chai");
const hre = require("hardhat");
describe("AdminAuthentication", function () {
  let AdminAuthentication;
  let adminAuthentication;
  let adminAddress;

  beforeEach(async function () {
    // Deploy the contract before each test
    AdminAuthentication = await hre.ethers.getContractFactory("AdminAuthentication");
    adminAuthentication = await AdminAuthentication.deploy();
    await adminAuthentication.waitForDeployment();

    // Get the first account as the admin address
    [adminAddress] = await hre.ethers.getSigners();
  });

  it("should add admin", async function () {
    // Add an admin
    await adminAuthentication.addAdmin(adminAddress.address, "adminPassword");

    
  });

  it("should login admin", async function () {
    // Add an admin
    await adminAuthentication.addAdmin(adminAddress.address, "adminPassword");

    // Login with correct password
    const loggedIn = await adminAuthentication.login("adminPassword");
    expect(loggedIn).to.equal(true);

    // Login with incorrect password
    await expect(adminAuthentication.login("wrongPassword")).to.be.revertedWith("Incorrect password");
  });

  it("should add policy", async function () {
    // Add an admin
    await adminAuthentication.addAdmin(adminAddress.address, "adminPassword");

    // Add a policy
    await adminAuthentication.addPolicy("Policy Title", "Policy Description");

    // Check if the policy exists
    const policy = await adminAuthentication.policies(1);
    expect(policy.title).to.equal("Policy Title");
    expect(policy.description).to.equal("Policy Description");
  });

  it("should revert when adding admin with empty password", async function () {
    // Attempt to add an admin with an empty password
    await expect(adminAuthentication.addAdmin(adminAddress.address, "")).to.be.revertedWith("Empty password");
  });

  it("should revert when logging in with empty password", async function () {
    // Add an admin
    await adminAuthentication.addAdmin(adminAddress.address, "adminPassword");

    // Attempt to login with an empty password
    await expect(adminAuthentication.login("")).to.be.revertedWith("Empty password");
  });

  it("should revert when admin already exists", async function () {
    // Add an admin
    await adminAuthentication.addAdmin(adminAddress.address, "adminPassword");

    // Attempt to add the same admin again
    await expect(adminAuthentication.addAdmin(adminAddress.address, "newPassword")).to.be.revertedWith("Admin already exists");
  });

  it("should revert when logging in with non-existent admin", async function () {
    // Deploy the contract with no admins added
    const adminAuthentication = await AdminAuthentication.deploy();
  
    // Attempt to log in with an address that is not registered as an admin
    const nonAdminAddress = "0x1234567890123456789012345678901234567890";
  
    // Specify the sender address using the 'connect' method
    const signer = await hre.ethers.provider.getSigner(nonAdminAddress);
    const adminAuthenticationConnected = adminAuthentication.connect(signer);
  
    // Call the login function
    try {
      await adminAuthenticationConnected.login("password");
      // If the login function didn't revert, the test should fail
      throw new Error("Expected login to revert");
    } catch (error) {
      // Check if the error message matches the expected revert reason
      expect(error.message).to.contain("Admin does not exist");
    }
  });
  
  it("should handle policy ID collision", async function () {
    // Add an admin
    await adminAuthentication.addAdmin(adminAddress.address, "adminPassword");

    // Add a policy with ID 1
    await adminAuthentication.addPolicy("Policy Title 1", "Policy Description 1");

    // Add another policy, which should have ID 2
    await adminAuthentication.addPolicy("Policy Title 2", "Policy Description 2");

    // Check if the policy with ID 2 exists
    const policy = await adminAuthentication.policies(2);
    expect(policy.title).to.equal("Policy Title 2");
    expect(policy.description).to.equal("Policy Description 2");
  });

  it("should handle Unicode characters in passwords", async function () {
    // Add an admin with a password containing Unicode characters
    await adminAuthentication.addAdmin(adminAddress.address, "😀🔑😀");

    // Login with the Unicode password
    const loggedIn = await adminAuthentication.login("😀🔑😀");
    expect(loggedIn).to.equal(true);
  });
  
  it("should handle large number of policies", async function () {
    // Deploy the contract
    const adminAuthentication = await AdminAuthentication.deploy();
  
    // Add an admin
    await adminAuthentication.addAdmin(adminAddress.address, "adminPassword");
  
    // Add multiple policies
    const numPolicies = 10;
  
    for (let i = 0; i < numPolicies; i++) {
      await adminAuthentication.addPolicy(`Policy Title ${i}`, `Policy Description ${i}`);
    }
  
    // Check if the last policy added exists
    const lastPolicyId = numPolicies;
    const lastPolicy = await adminAuthentication.policies(lastPolicyId);
    expect(lastPolicy.title).to.equal(`Policy Title ${numPolicies - 1}`);
    expect(lastPolicy.description).to.equal(`Policy Description ${numPolicies - 1}`);
  });
});
